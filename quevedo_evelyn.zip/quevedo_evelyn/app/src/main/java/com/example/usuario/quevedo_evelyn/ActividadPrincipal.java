package com.example.usuario.quevedo_evelyn;

import android.support.annotation.ArrayRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class ActividadPrincipal extends AppCompatActivity {
    TextView dato1, dato2, dato3, dato4;
    TextView valor1,valor2, valor3, valor4;
    Button boton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_principal);
        dato1=(TextView)findViewById(R.id.txt1);
        dato2=(TextView)findViewById(R.id.txt2);
        dato3=(TextView)findViewById(R.id.txt3);
        dato4=(TextView)findViewById(R.id.txt4);
        valor1=(TextView)findViewById(R.id.txt5);
        valor2=(TextView)findViewById(R.id.txt6);
        valor3=(TextView)findViewById(R.id.txt7);
        valor4=(TextView)findViewById(R.id.txt8);
        boton=(Button)findViewById(R.id.btnleer);

                InputStream input =getResources().openRawResource(R.raw.raw_archivo);
                BufferedReader lector=new BufferedReader(new InputStreamReader(input));

                try {
                    String cadena= lector.readLine();

                    String[]arreglo=cadena.split(";");
                    String pro1=arreglo[0].split(",")[0];
                    String pre1=arreglo[0].split(",")[1];



                    String[]arreglo2=cadena.split(";");
                    String pro2=arreglo2[1].split(",")[0];
                    String pre2=arreglo2[1].split(",")[1];


                    String[]arreglo3=cadena.split(";");
                    String pro3=arreglo3[2].split(",")[0];
                    String pre3=arreglo3[2].split(",")[1];


                    String[]arreglo4=cadena.split(";");
                    String pro4=arreglo4[3].split(",")[0];
                    String pre4=arreglo4[3].split(",")[1];

                    dato1.setText(pro1);
                    valor1.setText(pre1);
                    dato2.setText(pro2);
                    valor2.setText(pre2);
                    dato3.setText(pro3);
                    valor3.setText(pre3);
                   dato4.setText(pro4);
                    valor4.setText(pre4);



                } catch (IOException e) {
                    e.printStackTrace();
                }
            }}